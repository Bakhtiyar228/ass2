package bridge_design_pattern;

// Abstract class representing a TV with a remote control
abstract class TV
{
    Remote remote; // Reference to the remote control
    TV(Remote r)
    {
        this.remote = r;
    }

    abstract void on();
    abstract void off();
}

// Concrete TV class, e.g., Sony TV
class Sony extends TV
{
    Remote remoteType;
    Sony(Remote r)
    {
        super(r);
        this.remoteType = r;
    }

    // Implementation of the TV's "on" method, which delegates to the remote control
    public void on()
    {
        System.out.print("Sony TV ON: ");
        remoteType.on();
    }

    // Implementation of the TV's "off" method, which delegates to the remote control
    public void off()
    {
        System.out.print("Sony TV OFF: ");
        remoteType.off();
    }
}

// Another concrete TV class, e.g., Philips TV
class Philips extends TV
{
    Remote remoteType;
    Philips(Remote r)
    {
        super(r);
        this.remoteType = r;
    }

    // Implementation of the TV's "on" method, which delegates to the remote control
    public void on()
    {
        System.out.print("Philips TV ON: ");
        remoteType.on();
    }

    // Implementation of the TV's "off" method, which delegates to the remote control
    public void off()
    {
        System.out.print("Philips TV OFF: ");
        remoteType.off();
    }
}

// Interface for remote controls
interface Remote
{
    public void on();
    public void off();
}

// Concrete implementation of the old remote control
class OldRemote implements Remote
{
    @Override
    public void on()
    {
        System.out.println("ON with Old Remote");
    }

    @Override
    public void off()
    {
        System.out.println("OFF with Old Remote");
    }
}

// Concrete implementation of the new remote control
class NewRemote implements Remote
{
    @Override
    public void on()
    {
        System.out.println("ON with New Remote");
    }

    @Override
    public void off()
    {
        System.out.println("OFF with New Remote");
    }
}

public class BridgePattern
{
    public static void main(String[] args)
    {
        // Create Sony TV with an old remote and demonstrate turning it on and off
        TV sonyOldRemote = new Sony(new OldRemote());
        sonyOldRemote.on();
        sonyOldRemote.off();
        System.out.println();

        // Create Sony TV with a new remote and demonstrate turning it on and off
        TV sonyNewRemote = new Sony(new NewRemote());
        sonyNewRemote.on();
        sonyNewRemote.off();
        System.out.println();

        // Create Philips TV with an old remote and demonstrate turning it on and off
        TV philipsOldRemote = new Philips(new OldRemote());
        philipsOldRemote.on();
        philipsOldRemote.off();
        System.out.println();

        // Create Philips TV with a new remote and demonstrate turning it on and off
        TV philipsNewRemote = new Philips(new NewRemote());
        philipsNewRemote.on();
        philipsNewRemote.off();
    }
}
