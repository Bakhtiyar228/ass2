package singleton_design_pattern;

// Singleton using Eager Initialization
class SingletonEagar
{
  private static SingletonEagar instance = new SingletonEagar(); // Eagerly initialized instance
  private SingletonEagar()
  {
    // Private constructor to prevent external instantiation
  }

  public static SingletonEagar getInstance()
  {
    return instance;
  }
}

// Singleton with Lazy Initialization (not thread-safe)
class Singleton
{
  private static Singleton instance; // Singleton instance (null by default)
  private Singleton()
  {
    // Private constructor to prevent external instantiation
  }

  public static Singleton getInstance()
  {
    if(instance == null)
    {
      instance = new Singleton(); // Lazy initialization when needed
    }
    return instance;
  }
}

// Singleton with Synchronized Method (thread-safe but has performance overhead)
class SingletonSynchronizedMethod
{
  private static SingletonSynchronizedMethod instance; // Singleton instance (null by default)
  private SingletonSynchronizedMethod()
  {
    // Private constructor to prevent external instantiation
  }

  public static synchronized SingletonSynchronizedMethod getInstance()
  {
    if(instance == null)
    {
      instance = new SingletonSynchronizedMethod(); // Lazy initialization with synchronized method
    }
    return instance;
  }
}

// Singleton with Double-Checked Locking (thread-safe and efficient)
class SingletonSynchronized
{
  private static SingletonSynchronized instance; // Singleton instance (null by default)
  private SingletonSynchronized()
  {
    // Private constructor to prevent external instantiation
  }

  public static SingletonSynchronized getInstance()
  {
    if(instance == null)
    {
      synchronized (SingletonSynchronized.class) // Double-checked locking for efficiency
      {
        if(instance == null)
        {
          instance = new SingletonSynchronized(); // Lazy initialization with double-checked locking
        }
      }
    }
    return instance;
  }
}

public class SingletonPattern
{
  public static void main(String[] args)
  {
    // Create and access a Singleton instance
    SingletonSynchronized instance = SingletonSynchronized.getInstance();
    System.out.println(instance);

    // Access the same Singleton instance again
    SingletonSynchronized instance1 = SingletonSynchronized.getInstance();
    System.out.println(instance1);
  }
}
