package proxy_design_pattern;

// Interface representing a database executor
interface DatabaseExecuter
{
	public void executeDatabase(String query) throws Exception;
}

// Concrete implementation of the DatabaseExecutor interface
class DatabaseExecuterImpl implements DatabaseExecuter
{
	@Override
	public void executeDatabase(String query) throws Exception
	{
		System.out.println("Going to execute Query: " + query);
	}
}

// Proxy class implementing the DatabaseExecutor interface
class DatabaseExecuterProxy implements DatabaseExecuter
{
	boolean ifAdmin; // Indicates if the user is an admin
	DatabaseExecuterImpl dbExecuter; // Real database executor instance

	public DatabaseExecuterProxy(String name, String passwd)
	{
		if (name == "Admin" && passwd == "Admin@123")
		{
			ifAdmin = true; // Check if the user is an admin
		}
		dbExecuter = new DatabaseExecuterImpl(); // Create a real database executor
	}

	@Override
	public void executeDatabase(String query) throws Exception
	{
		if (ifAdmin)
		{
			dbExecuter.executeDatabase(query); // Admins can execute any query
		}
		else
		{
			if (query.equals("DELETE"))
			{
				throw new Exception("DELETE not allowed for non-admin user");
			}
			else
			{
				dbExecuter.executeDatabase(query); // Non-admin users can execute non-DELETE queries
			}
		}
	}
}

public class ProxyPattern
{
	public static void main(String[] args) throws Exception
	{
		// Create a non-admin user and attempt to execute DELETE and other queries
		DatabaseExecuter nonAdminExecuter = new DatabaseExecuterProxy("NonAdmin", "Admin@123");
		nonAdminExecuter.executeDatabase("DELEE"); // Non-admin attempting DELETE

		// Create another non-admin user and attempt to execute DELETE
		DatabaseExecuter nonAdminExecuterDELETE = new DatabaseExecuterProxy("NonAdmin", "Admin@123");
		nonAdminExecuterDELETE.executeDatabase("DELETE"); // Non-admin attempting DELETE

		// Create an admin user and execute DELETE query
		DatabaseExecuter adminExecuter = new DatabaseExecuterProxy("Admin", "Admin@123");
		adminExecuter.executeDatabase("DELETE"); // Admin executing DELETE
	}
}
