package factory_design_pattern;

// Abstract class representing a generic vehicle
abstract class Vehicle
{
	public abstract int getWheel(); // Method to get the number of wheels
	public String toString() // Default toString method to print the number of wheels
	{
		return "Wheel: " + this.getWheel();
	}
}

// Concrete class representing a Car, a type of vehicle
class Car extends Vehicle
{
	int wheel; // Number of wheels for a car

	// Constructor for Car
	Car(int wheel)
	{
		this.wheel = wheel;
	}

	@Override
	public int getWheel()
	{
		return this.wheel;
	}
}

// Concrete class representing a Bike, another type of vehicle
class Bike extends Vehicle
{
	int wheel; // Number of wheels for a bike

	// Constructor for Bike
	Bike(int wheel)
	{
		this.wheel = wheel;
	}

	@Override
	public int getWheel()
	{
		return this.wheel;
	}
}

// Factory class responsible for creating instances of different vehicle types
class VehicleFactory
{
	public static Vehicle getInstance(String type, int wheel)
	{
		if(type.equals("car"))
		{
			return new Car(wheel); // Create and return a Car instance
		}
		else if(type.equals("bike"))
		{
			return new Bike(wheel); // Create and return a Bike instance
		}
		return null; // If an invalid type is provided, return null
	}
}

public class FactoryPattern
{
	public static void main(String[] args)
	{
		// Use the VehicleFactory to create a Car with 4 wheels and a Bike with 2 wheels
		Vehicle car = VehicleFactory.getInstance("car", 4);
		System.out.println(car); // Prints "Wheel: 4"

		Vehicle bike = VehicleFactory.getInstance("bike", 2);
		System.out.println(bike); // Prints "Wheel: 2"
	}
}
