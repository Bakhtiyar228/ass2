package prototype_design_pattern;

import java.util.ArrayList;
import java.util.List;

// Prototype class that implements Cloneable to allow object cloning
class Vehicle implements Cloneable
{
  private List<String> vehicleList;

  public Vehicle()
  {
    this.vehicleList = new ArrayList<String>();
  }

  public Vehicle(List<String> list)
  {
    this.vehicleList = list;
  }

  public void insertData()
  {
    // Sample data is inserted into the vehicle list
    vehicleList.add("Honda amaze");
    vehicleList.add("Audi A4");
    vehicleList.add("Hyundai Creta");
    vehicleList.add("Maruti Baleno");
    vehicleList.add("Renault Duster");
  }

  public List<String> getVehicleList()
  {
    return this.vehicleList;
  }

  @Override
  public Object clone() throws CloneNotSupportedException
  {
    // Perform deep copy by creating a new list and copying elements from the original list
    List<String> tempList = new ArrayList<String>();

    for (String s : this.getVehicleList())
    {
      tempList.add(s);
    }

    return new Vehicle(tempList);
  }
}

public class PrototypePattern
{
  public static void main(String[] args) throws CloneNotSupportedException
  {
    Vehicle a = new Vehicle();
    a.insertData();

    // Clone the original Vehicle object
    Vehicle b = (Vehicle) a.clone();
    List<String> list = b.getVehicleList();

    // Modify the cloned object's list
    list.add("Honda new Amaze");

    // Print the original and cloned lists
    System.out.println(a.getVehicleList()); // Original list
    System.out.println(list); // Cloned list

    // Remove an item from the cloned list
    b.getVehicleList().remove("Audi A4");

    // Print the modified cloned list and the original list
    System.out.println(list); // Modified cloned list
    System.out.println(a.getVehicleList()); // Original list
  }
}
