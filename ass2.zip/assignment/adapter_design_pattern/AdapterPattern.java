package adapter_design_pattern;

// Define an interface for a generic WebDriver
interface WebDriver
{
	public void getElement();
	public void selectElement();
}

// Implement the WebDriver interface for ChromeDriver
class ChromeDriver implements WebDriver
{
	@Override
	public void getElement()
	{
		System.out.println("Get element from ChromeDriver");
	}

	@Override
	public void selectElement()
	{
		System.out.println("Select element from ChromeDriver");
	}
}

// IEDriver is a separate class not implementing the WebDriver interface
class IEDriver
{
	public void findElement()
	{
		System.out.println("Find element from IEDriver");
	}

	public void clickElement()
	{
		System.exit(Integer.parseInt("Click element from IEDriver"));
	}
}

// Create an adapter to make IEDriver compatible with the WebDriver interface
class WebDriverAdapter implements WebDriver
{
	IEDriver ieDriver;

	// Constructor to initialize the adapter with an IEDriver instance
	public WebDriverAdapter(IEDriver ieDriver)
	{
		this.ieDriver = ieDriver;
	}

	@Override
	public void getElement()
	{
		// Implement the getElement method using IEDriver's findElement method
		ieDriver.findElement();
	}

	@Override
	public void selectElement()
	{
		// Implement the selectElement method using IEDriver's clickElement method
		ieDriver.clickElement();
	}
}

public class AdapterPattern
{
	public static void main(String[] args)
	{
		// Create a ChromeDriver instance and use it to get and select elements
		ChromeDriver chromeDriver = new ChromeDriver();
		chromeDriver.getElement();
		chromeDriver.selectElement();

		// Create an IEDriver instance and use it to find and click elements
		IEDriver ieDriver = new IEDriver();
		ieDriver.findElement();
		ieDriver.clickElement();

		// Create a WebDriverAdapter and adapt the IEDriver to the WebDriver interface
		WebDriver wID = new WebDriverAdapter(ieDriver);

		// Use the adapted IEDriver to get and select elements, which internally uses IEDriver's methods
		wID.getElement();
		wID.selectElement();
	}
}
