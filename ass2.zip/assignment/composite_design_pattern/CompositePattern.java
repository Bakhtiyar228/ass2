package composite_design_pattern;

import java.util.ArrayList;
import java.util.List;

// Abstract class representing an account
abstract class Account
{
  public abstract float getBalance();
}

// Concrete class for a Deposit Account
class DepositAccount extends Account
{
  private String accountNo;
  private float accountBalance;

  public DepositAccount(String accountNo, float accountBalance)
  {
    super();
    this.accountNo = accountNo;
    this.accountBalance = accountBalance;
  }

  public float getBalance()
  {
    return accountBalance;
  }
}

// Concrete class for a Savings Account
class SavingsAccount extends Account
{
  private String accountNo;
  private float accountBalance;

  public SavingsAccount(String accountNo, float accountBalance)
  {
    super();
    this.accountNo = accountNo;
    this.accountBalance = accountBalance;
  }

  public float getBalance()
  {
    return accountBalance;
  }
}

// Composite class that represents a collection of accounts
class CompositeAccount extends Account
{
  private float totalBalance;
  private List<Account> accountList = new ArrayList<Account>();

  public float getBalance()
  {
    totalBalance = 0;
    for (Account acc : accountList)
    {
      totalBalance = totalBalance + acc.getBalance();
    }
    return totalBalance;
  }

  public void addAccount(Account acc)
  {
    accountList.add(acc);
  }

  public void removeAccount(Account acc)
  {
    accountList.remove(acc);
  }
}

public class CompositePattern
{
  public static void main(String[] args)
  {
    // Create a composite account
    CompositeAccount component = new CompositeAccount();

    // Add deposit accounts and a savings account to the composite account
    component.addAccount(new DepositAccount("DA001", 100));
    component.addAccount(new DepositAccount("DA002", 150));
    component.addAccount(new SavingsAccount("SA001", 200));

    // Calculate and print the total balance of the composite account
    float totalBalance = component.getBalance();
    System.out.println("Total Balance : " + totalBalance);
  }
}
